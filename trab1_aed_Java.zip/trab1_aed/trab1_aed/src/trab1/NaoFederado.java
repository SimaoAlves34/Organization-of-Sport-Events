package trab1;

    /**
    *Criação da classe NaoFederado
    *Herança da class Atleta
    */

public class NaoFederado extends Atleta{
    
     /**
    *Atributos da classe NaoFederado
    */
    
    private boolean saude;
    
    /** Método Construtor da Classe NaoFederado */
    
    public NaoFederado(String nif){
        super(nif);
    }
}
